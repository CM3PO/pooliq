import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Waves, 
  Wrench, 
  Hammer, 
  PaintBucket, 
  Search, 
  AlertTriangle,
  CheckCircle2,
  Clock,
  Shield,
  Star
} from "lucide-react";

export default function ServicesSection() {
  const services = [
    {
      id: "cleaning",
      title: "Pool Cleaning",
      description: "Weekly maintenance, chemical balancing, and debris removal to keep your pool sparkling clean year-round.",
      icon: Waves,
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
      features: [
        "Weekly service visits",
        "Chemical testing & balancing", 
        "Skimming & vacuuming",
        "Filter maintenance"
      ],
      color: "bg-pool-blue"
    },
    {
      id: "repair",
      title: "Pool Repair",
      description: "Expert repairs for pumps, filters, heaters, and all pool equipment to restore optimal performance.",
      icon: Wrench,
      image: "https://images.unsplash.com/photo-1621905252507-b35492cc74b4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
      features: [
        "Pump & motor repair",
        "Filter system service",
        "Heater troubleshooting", 
        "Automation systems"
      ],
      color: "bg-pool-blue"
    },
    {
      id: "construction",
      title: "Pool Construction",
      description: "Custom pool design and construction to create your perfect backyard oasis with professional installation.",
      icon: Hammer,
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
      features: [
        "Custom design consultation",
        "Excavation & installation",
        "Plumbing & electrical",
        "Landscaping integration"
      ],
      color: "bg-pool-blue"
    },
    {
      id: "remodeling", 
      title: "Pool Remodeling",
      description: "Transform your existing pool with modern upgrades, new finishes, and enhanced features.",
      icon: PaintBucket,
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
      features: [
        "Surface refinishing",
        "Tile & coping updates",
        "LED lighting systems",
        "Water feature additions"
      ],
      color: "bg-pool-blue"
    },
    {
      id: "leak-detection",
      title: "Leak Detection", 
      description: "Advanced leak detection technology to quickly locate and repair leaks, saving water and money.",
      icon: Search,
      image: "https://images.unsplash.com/photo-1558449028-b53a39d100fc?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
      features: [
        "Electronic leak detection",
        "Pressure testing", 
        "Underground pipe location",
        "Structural leak repair"
      ],
      color: "bg-pool-blue"
    }
  ];

  const whyChooseUs = [
    {
      icon: Shield,
      title: "Licensed & Insured",
      description: "Fully licensed, bonded, and insured for your peace of mind."
    },
    {
      icon: Clock,
      title: "Reliable Service", 
      description: "Consistent, on-time service you can count on every week."
    },
    {
      icon: Star,
      title: "5-Star Reviews",
      description: "Hundreds of satisfied customers throughout Austin area."
    },
    {
      icon: CheckCircle2,
      title: "Service Guarantee",
      description: "100% satisfaction guarantee on all our services."
    }
  ];

  return (
    <section id="services" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-800 mb-4" data-testid="services-title">
            Our Pool Services for Austin Residents
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="services-description">
            Complete pool care solutions from routine maintenance to custom construction. We're your trusted Austin pool experts.
          </p>
        </div>

        {/* Service Cards Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {services.map((service) => {
            const IconComponent = service.icon;
            return (
              <Card key={service.id} className="group hover:shadow-2xl transition-all duration-300 border border-gray-100 overflow-hidden" data-testid={`service-card-${service.id}`}>
                <div className="relative">
                  <img 
                    src={service.image} 
                    alt={`${service.title} - Professional pool service in Austin`}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    data-testid={`service-image-${service.id}`}
                  />
                  <div className={`absolute top-4 left-4 w-12 h-12 ${service.color} rounded-full flex items-center justify-center shadow-lg`}>
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-2xl font-bold text-gray-800 flex items-center gap-3" data-testid={`service-title-${service.id}`}>
                    {service.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-gray-600 mb-4" data-testid={`service-description-${service.id}`}>
                    {service.description}
                  </p>
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm text-gray-600" data-testid={`service-feature-${service.id}-${index}`}>
                        <CheckCircle2 className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className="w-full bg-pool-blue hover:bg-pool-blue-dark text-white font-semibold transition-colors"
                    data-testid={`service-button-${service.id}`}
                  >
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            );
          })}

          {/* Emergency Service Card */}
          <Card className="bg-gradient-to-br from-red-500 to-red-600 text-white group hover:shadow-2xl transition-all duration-300 border-0" data-testid="emergency-service-card">
            <CardHeader>
              <CardTitle className="text-2xl font-bold flex items-center gap-3" data-testid="emergency-service-title">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                  <AlertTriangle className="w-6 h-6" />
                </div>
                Emergency Service
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4" data-testid="emergency-service-description">
                24/7 emergency pool service for urgent repairs and equipment failures.
              </p>
              <ul className="space-y-2 mb-6 text-red-100">
                {["Same-day service", "Emergency repairs", "Equipment failures", "Water quality issues"].map((feature, index) => (
                  <li key={index} className="flex items-center text-sm" data-testid={`emergency-feature-${index}`}>
                    <CheckCircle2 className="w-4 h-4 mr-2 flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
              <Button 
                variant="secondary"
                className="w-full bg-white text-red-600 hover:bg-red-50 font-semibold"
                asChild
                data-testid="emergency-call-button"
              >
                <a href="tel:512-XXX-XXXX">Call Now</a>
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Why Choose PoolIQ Section */}
        <div className="bg-pool-gray rounded-2xl p-8 lg:p-12">
          <div className="text-center mb-12">
            <h3 className="text-3xl lg:text-4xl font-bold text-gray-800 mb-4" data-testid="why-choose-title">
              Why Choose PoolIQ?
            </h3>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto" data-testid="why-choose-description">
              Experience the difference with Austin's most trusted pool service company.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {whyChooseUs.map((item, index) => {
              const IconComponent = item.icon;
              return (
                <div key={index} className="text-center group" data-testid={`why-choose-${index}`}>
                  <div className="w-16 h-16 bg-pool-blue rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 shadow-pool">
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="text-xl font-bold text-gray-800 mb-2" data-testid={`why-choose-title-${index}`}>
                    {item.title}
                  </h4>
                  <p className="text-gray-600" data-testid={`why-choose-description-${index}`}>
                    {item.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
