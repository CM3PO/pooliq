# PoolIQ - Pool Service Website

## Overview

PoolIQ is a React-based web application for a pool service company operating in Austin, Texas and surrounding areas. The application serves as a marketing website showcasing pool cleaning, repair, construction, and maintenance services. It includes customer contact forms, quote request functionality, and comprehensive service information with a focus on local SEO optimization.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React 18** with TypeScript for the user interface
- **Vite** as the build tool and development server
- **Wouter** for client-side routing (lightweight React Router alternative)
- **TanStack Query** for server state management and API caching
- **React Hook Form** with Zod validation for form handling
- **Tailwind CSS** with custom pool-themed color palette for styling
- **Shadcn/ui** component library for consistent UI elements

### Backend Architecture
- **Express.js** server with TypeScript
- **RESTful API** endpoints for contact forms and quote requests
- **In-memory storage** implementation with interface for future database integration
- **Zod schemas** for request validation shared between client and server
- **Custom middleware** for request logging and error handling

### Database Schema
- **Drizzle ORM** configured for PostgreSQL with schema generation
- **Contact forms table**: stores customer inquiries with service type categorization
- **Quote requests table**: manages quote requests with status tracking
- **UUID primary keys** with timestamp tracking for all records

### Form Management
- **Contact Form**: General customer inquiries with service type selection
- **Quote Form**: Detailed quote requests with terms acceptance
- **Real-time validation** using Zod schemas
- **Success/error toast notifications** for user feedback

### SEO Optimization
- **Local business schema markup** for search engines
- **Service area targeting** for Austin, Georgetown, Round Rock, Cedar Park, Pflugerville
- **Service-specific landing pages** with targeted keywords
- **Meta descriptions** and title optimization for pool service searches

### Responsive Design
- **Mobile-first approach** with Tailwind CSS breakpoints
- **Custom mobile navigation** with collapsible menu
- **Optimized form layouts** for mobile and desktop
- **Progressive enhancement** for various screen sizes

## External Dependencies

### Core Framework Dependencies
- **React ecosystem**: React 18, React DOM, TypeScript support
- **Vite**: Modern build tool with hot module replacement
- **Express.js**: Node.js web framework for API endpoints

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework with custom configuration
- **Radix UI**: Headless UI components for accessibility
- **Shadcn/ui**: Pre-built component library with consistent styling
- **Lucide React**: Icon library for consistent iconography

### Form and Validation
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: TypeScript-first schema validation
- **Hookform/resolvers**: Integration between React Hook Form and Zod

### Data Management
- **TanStack Query**: Server state management and caching
- **Drizzle ORM**: Type-safe SQL toolkit for database operations
- **Neon Database**: Serverless PostgreSQL database (configured but not actively used)

### Development Tools
- **TypeScript**: Static type checking and improved developer experience
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Tailwind integration
- **Replit-specific plugins**: Development environment integration

### Production Considerations
- **Connect-pg-simple**: PostgreSQL session store (prepared for future session management)
- **Date-fns**: Date manipulation library
- **Class-variance-authority**: Utility for managing CSS class variants

## Deployment and GitHub Setup

### GitHub Repository Setup
- **README.md**: Comprehensive documentation with setup instructions
- **LICENSE**: MIT license for open source distribution
- **.gitignore**: Excludes node_modules, build files, and sensitive data
- **GitHub-ready**: Project structure optimized for GitHub hosting

### Deployment Options
1. **Replit Deployment**: Recommended for quick deployment with built-in hosting
2. **Vercel/Netlify**: Static site hosting with serverless functions
3. **Traditional Hosting**: VPS or shared hosting with Node.js support

### Key Customization Points
- **Phone Numbers**: Replace `512-XXX-XXXX` with actual business phone
- **Email Addresses**: Update `info@pooliq.com` with business email
- **Service Areas**: Modify cities and locations in service area components
- **Business Hours**: Update operating hours in contact and footer components
- **Pricing**: Adjust service pricing in quotes and services pages

### SEO and Local Business Optimization
- **Schema Markup**: Local business structured data for search engines
- **Austin-focused Keywords**: Optimized for "Austin pool service" searches
- **Service Area Targeting**: Content optimized for surrounding cities
- **Mobile-first Design**: Responsive layout for local search traffic